---
layout:    post
title:     "First week in U.S"
date:      2016-08-19
comment:   true
tags: [Personal]
---

Well. It's my fourth day at my aunt's house in Vancouver, WA. Everything here is amazing except the Jet Lag.

I will post some pictures later and here just start this topic.
