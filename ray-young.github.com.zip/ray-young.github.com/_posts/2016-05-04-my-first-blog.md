---
layout:    post
title:     "New Trip"
date:      2016-05-04
comments:  true
tags: [Personal]
---

I used to store my blogs at [cnblog][1], but now I will start move the old blogs here and translate them all in English. It will be a long task so I am not sure when it's finished. Anyway I will try my best.

Thanks to [Lirian Su][2], an awesome geek and nice guy, We worked together in developing a Version Control System at QAD Inc. and he taught me to use Git and Jekyll to publish and store my blogs.

Mostly I will publish articles about programming techinques and summaries. Sometimes I will publish some personal things like travel and feelings.

Have fun~~!

[1]: http://www.cnblogs.com/Raymond-Yang/
[2]: http://www.liriansu.com/
