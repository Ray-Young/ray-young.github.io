---
layout:    post
title:     "Implement Restful DAO Webservices based on Jersey"
date:      2016-08-23
comment:   true
tags: [Java, Jersey, WebService]
---

I will translate the main content later. You can refer my original blog [Blog][1] by now.

[1]: http://www.cnblogs.com/Raymond-Yang/p/5396340.html
