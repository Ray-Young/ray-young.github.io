---
layout: post
title: Keep Fighting
date: 2016-12-18
comments: true
tags: [Personal]
---

It has been four months since I came to Boston. Yesterday just finished the finals for this semester.

Just made Tofu soup for lunch with sauce bought from H-Mart. I used to believe Kaju Tofu Soup (One of the best Korea Tofu Soup in Boston) is the best Korea Tofu Soup in Boston, but now I see, with good sauce we can also make it by myself, and is really really cheap!

I Spent lots of money on eat in the four months. I used to recognize myself care little about food, but after months shity food cooked by myself, totally gave in. Then after 2 months eating outside, totally get poor.

Every time I spent another bill on eating, I said to myself, "well, I will make the money back"... But it seems a mock now. Not successful in the last job hunting, spend so much time and efforts, but still no good result. Too much darkness, where is the light T_T.

