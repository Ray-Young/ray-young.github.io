---
layout: post
title: Portable and Execuable Script in Linux
date: 2017-03-12
comments: true
tags: [Linux]
---
