---
layout: post
titie: "First Week at Boston"
date: 2016-09-07
comments: true
tags: [Personal]
---

### First Night
Arrived at Boston at 31 August, it's already very late after checking in the hotel and go to the market for the furniture. It's bit rainy at night.
![firstNight][1]

When I first got to my aunt's house, I only took 2 luggages with me. But when I came to Boston, I took 4 luggages with me... I don't know what I have bought in 
these two weeks...
![tooMuchLuggage][2]

### Check in Dorm
In September 1st, I came to the dorm. The outside scenery is pretty good.
![dormOutsideScenery][3]

But when you came inside the dorm... That's really a mess. A strong smell of 
formaldehyde... Really put me in a crazy situation.

Forget it. Let's see a good scenery of Boston.
![bostonScenery][4]

### Railway
It's a night railway picture of Boston. The traffic of Boston is similiar to 
Beijing. Both Boston and Beijing has a long history, which makes it hard to build modern traffic due to the ancient buildings.
![railway][5]

### Move in
Move in a room just like setup a development environment. The most difficult part in programming is not write a complex algorithm, but seting up the development environment. So as assemble the furniture and clean up the room. Let's see the result of my work.
![roomPicture][6]

![roomPicture][7]

![roomPicture][8]

### To be continue
~~~

[1]: /assets/FirstWeekInBU/firstNight.jpg
[2]: /assets/FirstWeekInBU/luggage.jpg
[3]: /assets/FirstWeekInBU/dormOutside.jpg
[4]: /assets/FirstWeekInBU/BostonPark.jpg
[5]: /assets/FirstWeekInBU/railway.jpg
[6]: /assets/FirstWeekInBU/roomInside1.jpg
[7]: /assets/FirstWeekInBU/roomInside2.jpg
[8]: /assets/FirstWeekInBU/roomInside3.jpg
