---
layout: post
title: Python tips
date: 2017-03-17
comments: true
tags: [Python]
---

### Why class method needs a self parameter
